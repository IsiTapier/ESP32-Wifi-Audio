var searchData=
[
  ['touch_5fpad_5ft_316',['touch_pad_t',['../audio__gpio_8h.html#ad974977a657d2e2ae20be08678c73ceb',1,'audio_gpio.h']]]
];
