var searchData=
[
  ['actionheadphonedetection_0',['actionHeadphoneDetection',['../class_audio_kit.html#a75fc2200b171c9b477f2f100b8a18104',1,'AudioKit']]],
  ['adc_5finput_1',['adc_input',['../struct_audio_kit_config.html#a8ae224cfd264634f4e09e6208cbcf6c0',1,'AudioKitConfig']]],
  ['arduino_20audiokit_20hal_2',['Arduino AudioKit HAL',['../index.html',1,'']]],
  ['audiokit_3',['AudioKit',['../class_audio_kit.html',1,'']]],
  ['audiokitconfig_4',['AudioKitConfig',['../struct_audio_kit_config.html',1,'']]],
  ['audiokitsettings_2eh_5',['AudioKitSettings.h',['../_audio_kit_settings_8h.html',1,'']]]
];
