var searchData=
[
  ['sample_5frate_86',['sample_rate',['../struct_audio_kit_config.html#adefddc85df8f2a25c605ce58b6dde31a',1,'AudioKitConfig']]]
];
