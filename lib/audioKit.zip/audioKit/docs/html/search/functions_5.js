var searchData=
[
  ['headphonestatus_53',['headphoneStatus',['../class_audio_kit.html#a0ad4e2e3004efe2769f9746df240b22a',1,'AudioKit']]]
];
