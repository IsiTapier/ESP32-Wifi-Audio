var searchData=
[
  ['ismaster_16',['isMaster',['../struct_audio_kit_config.html#a73b36d53ff8bc857cd626a6e2091944a',1,'AudioKitConfig']]],
  ['issdactive_17',['isSDActive',['../class_audio_kit.html#ae882b7e764b7b5fe978d470648cab80c',1,'AudioKit']]]
];
