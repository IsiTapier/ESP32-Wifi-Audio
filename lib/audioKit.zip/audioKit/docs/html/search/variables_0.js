var searchData=
[
  ['adc_5finput_80',['adc_input',['../struct_audio_kit_config.html#a8ae224cfd264634f4e09e6208cbcf6c0',1,'AudioKitConfig']]]
];
