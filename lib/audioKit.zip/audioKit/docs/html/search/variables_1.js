var searchData=
[
  ['bits_5fper_5fsample_81',['bits_per_sample',['../struct_audio_kit_config.html#a33583d45c4ab81f76d34712847e93907',1,'AudioKitConfig']]]
];
