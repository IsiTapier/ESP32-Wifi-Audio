var indexSectionsWithContent =
{
  0: "abcdefhimpsv",
  1: "a",
  2: "a",
  3: "abcdehipsv",
  4: "abcdfms",
  5: "a"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Pages"
};

