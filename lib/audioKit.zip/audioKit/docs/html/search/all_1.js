var searchData=
[
  ['begin_6',['begin',['../class_audio_kit.html#a903b3aee6597dfcb1de40f72f2b18a1b',1,'AudioKit']]],
  ['bits_5fper_5fsample_7',['bits_per_sample',['../struct_audio_kit_config.html#a33583d45c4ab81f76d34712847e93907',1,'AudioKitConfig']]],
  ['bitspersample_8',['bitsPerSample',['../struct_audio_kit_config.html#a3c15d27c3e5d9f8dbb304d21992bbbda',1,'AudioKitConfig']]]
];
