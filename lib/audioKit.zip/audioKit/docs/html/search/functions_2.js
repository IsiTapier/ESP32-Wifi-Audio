var searchData=
[
  ['config_50',['config',['../class_audio_kit.html#afca95325642573eab6c4ad5ce0924063',1,'AudioKit']]]
];
