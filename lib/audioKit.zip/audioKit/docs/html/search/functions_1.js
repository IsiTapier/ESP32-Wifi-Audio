var searchData=
[
  ['begin_48',['begin',['../class_audio_kit.html#a903b3aee6597dfcb1de40f72f2b18a1b',1,'AudioKit']]],
  ['bitspersample_49',['bitsPerSample',['../struct_audio_kit_config.html#a3c15d27c3e5d9f8dbb304d21992bbbda',1,'AudioKitConfig']]]
];
