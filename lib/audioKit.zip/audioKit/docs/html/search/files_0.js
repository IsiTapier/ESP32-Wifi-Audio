var searchData=
[
  ['audiokitsettings_2eh_46',['AudioKitSettings.h',['../_audio_kit_settings_8h.html',1,'']]]
];
