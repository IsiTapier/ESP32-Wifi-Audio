var searchData=
[
  ['spi_5fbus_5fconfig_5ft_217',['spi_bus_config_t',['../audio__gpio_8h.html#structspi__bus__config__t',1,'']]],
  ['spi_5fdevice_5finterface_5fconfig_5ft_218',['spi_device_interface_config_t',['../audio__gpio_8h.html#structspi__device__interface__config__t',1,'']]]
];
