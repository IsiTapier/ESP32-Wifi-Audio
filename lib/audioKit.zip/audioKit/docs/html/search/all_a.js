var searchData=
[
  ['sample_5frate_35',['sample_rate',['../struct_audio_kit_config.html#adefddc85df8f2a25c605ce58b6dde31a',1,'AudioKitConfig']]],
  ['samplerate_36',['sampleRate',['../struct_audio_kit_config.html#a33b28874f411a9c353f6a0fa62261289',1,'AudioKitConfig']]],
  ['setactive_37',['setActive',['../class_audio_kit.html#a64f95fca0a6f059803268dab33bf5d2c',1,'AudioKit']]],
  ['setmute_38',['setMute',['../class_audio_kit.html#aac99fb5dfb87a965451e076f404224fd',1,'AudioKit']]],
  ['setspeakeractive_39',['setSpeakerActive',['../class_audio_kit.html#aff34dc957824c6618a02e517a3b20221',1,'AudioKit']]],
  ['setupheadphonedetection_40',['setupHeadphoneDetection',['../class_audio_kit.html#accb5ea6f7ee146cbd512552e039ac5ac',1,'AudioKit']]],
  ['setupspi_41',['setupSPI',['../class_audio_kit.html#a8a690db491b4d735b5c405d17b6efcb0',1,'AudioKit']]],
  ['setvolume_42',['setVolume',['../class_audio_kit.html#adae205b1d34fa8c3c00ac891f980a7dd',1,'AudioKit']]]
];
