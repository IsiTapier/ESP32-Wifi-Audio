var searchData=
[
  ['master_5fslave_5fmode_85',['master_slave_mode',['../struct_audio_kit_config.html#add6c0604564d301e8582d8fc5a18d815',1,'AudioKitConfig']]]
];
