var searchData=
[
  ['defaultconfig_51',['defaultConfig',['../class_audio_kit.html#ae7f2a59c6f2bd31db85d75a65cec8ef0',1,'AudioKit']]]
];
