var searchData=
[
  ['codec_5fmode_9',['codec_mode',['../struct_audio_kit_config.html#ae4d2ebbeffb709eda313ff5dffdbb2ab',1,'AudioKitConfig']]],
  ['config_10',['config',['../class_audio_kit.html#afca95325642573eab6c4ad5ce0924063',1,'AudioKit']]]
];
