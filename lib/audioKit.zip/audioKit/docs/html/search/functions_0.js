var searchData=
[
  ['actionheadphonedetection_47',['actionHeadphoneDetection',['../class_audio_kit.html#a75fc2200b171c9b477f2f100b8a18104',1,'AudioKit']]]
];
